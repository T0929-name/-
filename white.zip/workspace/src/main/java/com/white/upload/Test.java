package com.white.upload;

import com.luhuiguo.chinese.ChineseUtils;
import com.luhuiguo.chinese.pinyin.Pinyin;
import com.luhuiguo.chinese.pinyin.PinyinFormat;

public class Test {

    public static void main(String[] args) {

       /* System.out.println(ChineseUtils.toPinyin("南京", PinyinFormat.ABBR_PINYIN_FORMAT));
        System.out.println(ChineseUtils.toPinyin("南京", PinyinFormat.DEFAULT_PINYIN_FORMAT));
        System.out.println(ChineseUtils.toPinyin("南京", PinyinFormat.TONELESS_PINYIN_FORMAT));
        System.out.println(ChineseUtils.toPinyin("南京", PinyinFormat.UNICODE_PINYIN_FORMAT));*/

       
    }
}

