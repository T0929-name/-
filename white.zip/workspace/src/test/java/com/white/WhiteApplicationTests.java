package com.white;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhiteApplicationTests {

    @Test
    void contextLoads() {
    }

}
